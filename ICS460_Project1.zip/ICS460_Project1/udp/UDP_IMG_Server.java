import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketAddress;
import java.util.logging.Logger;

import javax.imageio.ImageIO;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JProgressBar;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;
import javax.swing.border.EtchedBorder;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;

/**
 * ICS460 Project1 - UDP Image Server Metro State University
 * 
 * @author Richard Ketelsen, Jack Hysell, Jessica Maistrovich This program uses
 *         the UDP Protocol to break an image file into a bit array, it then
 *         breaks the bit array into packets and sends the packets to a client.
 * 
 *         Note: The following websites were used to learn about UDP:
 *         https://www.daniweb.com/programming/software-development/threads/248032/send-image-over-udp-problem
 *         http://tutorials.jenkov.com/java-networking/udp-datagram-sockets.html
 *         https://stackoverflow.com/questions/26571640/how-to-transfer-jpg-image-using-udp-socket
 *         http://javatongue.blogspot.com/2015/08/java-program-to-send-image-between.html
 */

public class UDP_IMG_Server extends JFrame {

	private File fileToSend;
	private long fileSize;
	private DatagramSocket dgServerSocket;
	private JLabel imgSpace = new JLabel("", SwingConstants.CENTER);
	private JProgressBar serverProgressBar = new JProgressBar();
	private byte[] byteArray;
	private SocketAddress sockAddress;
	private int totalDGSent;

	private final static Logger audit = Logger.getLogger("requests");
	private final static Logger errors = Logger.getLogger("errors");

	public UDP_IMG_Server(File fi, String ip) {

		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		setSize(600, 300);
		setLayout(null);
		add(serverProgressBar);
		serverProgressBar.setBounds(5, 5, 585, 50);
		add(imgSpace);
		setResizable(false);
		imgSpace.setVerticalTextPosition(SwingConstants.CENTER);
		imgSpace.setHorizontalTextPosition(SwingConstants.CENTER);
		imgSpace.setBounds(5, 40, 585, 215);
		imgSpace.setBorder(new EtchedBorder());
		serverProgressBar.setValue(0);
		serverProgressBar.setStringPainted(true);

		try {
			// prepare the file to send and open port 33780
			dgServerSocket = new DatagramSocket(33780);
			fileToSend = fi;
			fileSize = fileToSend.length();
			imgSpace.setText("<HTML><h1>UDP IMG Server</h1>" + "<h3>Prepared to send file: " + fileToSend.getName()
					+ "<br/>" + "Waiting for a connection.<br/>IP: " + InetAddress.getLocalHost().getHostAddress()
					+ "</h3></HTML>");
			// start the thread
			myThread.start();
		} catch (Exception ex) {
			JOptionPane.showMessageDialog(null, ex);
			System.exit(0);
		}
	}

	// create and run the thread
	Thread myThread = new Thread() {
		@Override
		public void run() {
			DatagramPacket serverDPacket;
			String instruct = "";
			try {
				// wait to receive request from client and wait for GETPIC
				while (instruct.startsWith("GETPIC") == false) {
					byteArray = new byte[1024];
					serverDPacket = new DatagramPacket(byteArray, 1024);
					dgServerSocket.setSoTimeout(0);
					dgServerSocket.receive(serverDPacket);
					sockAddress = serverDPacket.getSocketAddress();
					instruct = new String(byteArray);
				}
				// found a client and proceed with sending
				imgSpace.setText("<HTML><h1>UDP IMG Server</h1>" + "<h3>Connected to: " + sockAddress + "</h3></HTML>");

				// imgSpace.setText("connected to:" + sockAddress);
				BufferedImage bimg = ImageIO.read(fileToSend);
				int width = bimg.getWidth();
				int height = bimg.getHeight();

				// tell the client a file is coming and how big it is
				instruct = fileToSend.getName() + ":" + Long.toString(fileSize) + "$1" + Long.toString(width) + "$2"
						+ Long.toString(height) + "$3";

				System.out.println("---------------" + "\nFile Name: " + fileToSend.getName() + "\nFile Size: "
						+ Long.toString(fileSize) + "\nImage width: " + width + "\nImage height: " + height
						+ "\n---------------");
				serverDPacket = new DatagramPacket(instruct.getBytes(), instruct.length(), sockAddress);
				dgServerSocket.send(serverDPacket);
				int filePtsReadCount, sendCount;
				boolean failed;

				// take a break (timeout)
				dgServerSocket.setSoTimeout(1000);

				// create a filestream for bytes
				FileInputStream fileInpStream = new FileInputStream(fileToSend);
				filePtsReadCount = 1;
				imgSpace.setText("<HTML><h1>UDP IMG Server</h1>" + "<h3>Connected to: " + sockAddress
						+ "<br/>Sending file: " + fileToSend.getName() + "</h3></HTML>");

				// sending datagram packets
				for (int i = 0; i < fileSize;) {
					failed = false;
					byteArray = new byte[1024];
					filePtsReadCount = fileInpStream.read(byteArray);
					sendCount = 0;

					// START DO WHILE -- send datagram packets until filesize is reached
					do {
						serverDPacket = new DatagramPacket(byteArray, filePtsReadCount, sockAddress);
						// note: the send method
						dgServerSocket.send(serverDPacket);

						// recording the sending of the packets in variables
						sendCount++;
						totalDGSent++;
						int totalDGOffset = totalDGSent * 1024;
						System.out.println("Datagrams sent: " + (totalDGSent) + " Starting Offset: "
								+ (serverDPacket.getOffset() + totalDGOffset) + " Ending Offset: "
								+ (serverDPacket.getOffset() + serverDPacket.getLength() + totalDGOffset));
						imgSpace.setText("<HTML><h1>UDP IMG Server</h1>" + "<h3>Connected to: " + sockAddress
								+ "<br/>Sending file: " + fileToSend.getName() + "<br/>Total Packets Sent: "
								+ totalDGSent + "</h3></HTML>");
						Thread.sleep(80);

						try {
							dgServerSocket.receive(serverDPacket);
							instruct = new String(byteArray);

							// do we get an ack?
							if (instruct.contains("ACK") == false)
								throw new Exception();

						} catch (Exception ex) {
							failed = true;
						}
					} while (failed && sendCount < 5);
					if (sendCount < 5) {
						i += filePtsReadCount;
						serverProgressBar.setValue(i * 100 / (int) fileSize);
						serverProgressBar.setString(Integer.toString(serverProgressBar.getValue()) + " %");
					} else {
						JOptionPane.showMessageDialog(null, "Client is not receiving");
						System.exit(0);
					}
				}
				fileInpStream.close();
				System.out.println("-------------- \n File transfer complete.");
			} catch (Exception ex) {
				// consider adding exceptions
			}
		}
	};

	public static void main(String args[]) {
		// create the file object
		File fileToSend;

		// create the gui objects
		JFileChooser jFileChoos = new JFileChooser();
		jFileChoos.removeChoosableFileFilter(jFileChoos.getAcceptAllFileFilter());
		FileFilter ff = new FileNameExtensionFilter("Image file", "jpg", "png", "bmp", "jpeg", "gif");
		jFileChoos.addChoosableFileFilter(ff);
		jFileChoos.setFileSelectionMode(JFileChooser.FILES_ONLY);
		jFileChoos.setMultiSelectionEnabled(false);
		jFileChoos.setDialogTitle("Select a file to send");

		// prompt the user and wait for file to be chosen
		if (jFileChoos.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
			fileToSend = jFileChoos.getSelectedFile();
			new UDP_IMG_Server(fileToSend, "").setVisible(true);
		} else {
			JOptionPane.showMessageDialog(null, "File not Selected");
			System.exit(0);
		}

	}
}