import java.awt.Image;
import java.io.File;
import java.io.FileOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JProgressBar;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;
import javax.swing.border.EtchedBorder;

/**
 * ICS460 Project1 - UDP Image Client Metro State University
 * 
 * @author Richard Ketelsen, Jack Hysell, Jessica Maistrovich, This program uses
 *         the UDP Protocol to receives an image file from the server which has
 *         been broken into UDP packets, it then combines the packets into the
 *         original image.
 * 
 *         Note: The following websites were used to learn about UDP:
 *         https://www.daniweb.com/programming/software-development/threads/248032/send-image-over-udp-problem
 *         http://tutorials.jenkov.com/java-networking/udp-datagram-sockets.html
 *         https://stackoverflow.com/questions/26571640/how-to-transfer-jpg-image-using-udp-socket
 *         http://javatongue.blogspot.com/2015/08/java-program-to-send-image-between.html
 */

public class UDP_IMG_Client extends JFrame {

	private static final String HOSTNAME = "127.0.0.1";
	private File fileToReceive;
	private InetAddress clientIP;
	private String fileName;
	private long fileSize;
	private int width;
	private int height;
	private DatagramSocket dgClientSocket;
	private JLabel imgSpace = new JLabel("", SwingConstants.CENTER);
	private JProgressBar clientProgressBar = new JProgressBar();
	private byte[] byteArray;
	private int numDGReceived;

	public UDP_IMG_Client(File fi, String ip) {

		// after the IP address is entered (in main)
		// the client object is constructed with GUI elements to show image
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		// create the datagram socket and start the thread
		try {
			clientIP = InetAddress.getByName(ip);
			dgClientSocket = new DatagramSocket();
			imgSpace.setText("<HTML><b>Trying to connect to the given IP.</b></HTML>");
			myThread.start();
		} catch (Exception ex) {
			JOptionPane.showMessageDialog(null, ex);
			System.exit(0);
		}
	}

	// create a thread and run
	Thread myThread = new Thread() {
		@SuppressWarnings("resource")
		@Override
		public void run() {
			DatagramPacket clientDPacket;
			String instruct = "";
			try {
				// request from server "I'm ready to receive the packet"
				instruct = "GETPIC";
				clientDPacket = new DatagramPacket(instruct.getBytes(), instruct.length(), clientIP, 33780);
				dgClientSocket.send(clientDPacket);
				byteArray = new byte[1024];
				clientDPacket = new DatagramPacket(byteArray, 1024);
				dgClientSocket.receive(clientDPacket);
				instruct = new String(clientDPacket.getData());

				// create file to receive and set the file name, file size, width, and height
				fileToReceive = new File(
						System.getProperty("java.io.tmpdir") + "\\" + instruct.substring(0, instruct.indexOf(":")));
				System.out.println(instruct);
				fileName = instruct.substring(0, instruct.indexOf(":"));
				fileSize = Long.parseLong(instruct.substring(instruct.indexOf(":") + 1, instruct.indexOf("$1")));
				width = (int) Long.parseLong(instruct.substring(instruct.indexOf("$1") + 2, instruct.indexOf("$2")));
				height = (int) Long.parseLong(instruct.substring(instruct.indexOf("$2") + 2, instruct.indexOf("$3")));

				System.out.println("---------------" + "\nFile Name: " + fileName + "\nFile Size: " + fileSize
						+ "\nImage width: " + width + "\nImage height: " + height + "\n---------------");

				// set up GUI and use the width and height to set the correct size
				setSize(width + 15, height + 105);
				setLayout(null);
				add(clientProgressBar);
				clientProgressBar.setBounds(5, 5, width + 15, 50);
				add(imgSpace);
				setResizable(false);
				imgSpace.setVerticalTextPosition(SwingConstants.CENTER);
				imgSpace.setHorizontalTextPosition(SwingConstants.CENTER);
				imgSpace.setBounds(5, 60, width, height);
				imgSpace.setBorder(new EtchedBorder());
				clientProgressBar.setValue(0);
				clientProgressBar.setStringPainted(true);

				int i;

				// create the file output stream
				FileOutputStream fileOutStream = new FileOutputStream(fileToReceive);
				byteArray = new byte[1024];

				// timeout after 5 seconds
				dgClientSocket.setSoTimeout(5000);
				imgSpace.setText("Receiving image");
				for (i = 0; i < fileSize;) {
					byteArray = new byte[1024];
					clientDPacket = new DatagramPacket(byteArray, 1024);

					// receive the packets
					dgClientSocket.receive(clientDPacket);
					numDGReceived++;
					int totalDGOffset = numDGReceived * 1024;
					System.out.println("Datagrams received: " + (numDGReceived) + " Starting Offset: "
							+ (clientDPacket.getOffset() + totalDGOffset) + " Ending Offset: "
							+ (clientDPacket.getOffset() + clientDPacket.getLength() + totalDGOffset));

					if (clientDPacket.getLength() > 0) {
						i += clientDPacket.getLength();
						clientProgressBar.setValue(i * 100 / (int) fileSize);
						clientProgressBar.setString(Integer.toString(clientProgressBar.getValue()) + " %");
						fileOutStream.write(clientDPacket.getData());

						// ready the ack
						instruct = "ACK";
						// package the ack
						clientDPacket = new DatagramPacket(instruct.getBytes(), instruct.length(), clientIP, 33780);
						// send the ack "I have received the packet"
						dgClientSocket.send(clientDPacket);
					}
				}
				File fileToWrite = new File(fileName);
				fileToWrite.createNewFile(); // if file already exists will do nothing
				new FileOutputStream(fileToWrite, false);

				fileOutStream.close();
				imgSpace.setIcon(new ImageIcon(new ImageIcon(fileToReceive.getPath()).getImage()
						.getScaledInstance(imgSpace.getWidth(), imgSpace.getHeight(), Image.SCALE_SMOOTH)));
				imgSpace.setText("");
				System.out.println("-------------- \n File received and saved.");
				System.out.println("---------------" + "\nFile Name: " + fileName + "\nFile Size: " + fileSize / 1000
						+ "KB" + "\nImage width: " + width + "\nImage height: " + height + "\n---------------");

			} catch (Exception ex) {
				// consider handling the exception
			}
		}
	};

	public static void main(String args[]) {
		// Set IP on launch
		new UDP_IMG_Client(null, HOSTNAME).setVisible(true);
	}
}